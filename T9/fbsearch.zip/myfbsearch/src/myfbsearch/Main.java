/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfbsearch;

import javax.swing.SwingUtilities;
import myfbsearch.Model.TableModelfbsearch;
import myfbsearch.View.fbsearchView;
 

/**
 *
 * @author francismschappo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            new fbsearchView().setVisible(true);
        });
    }
    }
    

