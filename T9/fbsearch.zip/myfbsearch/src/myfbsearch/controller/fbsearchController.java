/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfbsearch.controller;


import myfbsearch.Model.TableModelfbsearch;
import myfbsearch.View.fbsearchView;

/**
 *
 * @author francismschappo
 */
public class fbsearchController {
//    private myfbsearch.Model model;
    
    
}
