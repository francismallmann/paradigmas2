/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfbsearch.controller;

import myfbsearch.Model.fbsearch;
import myfbsearch.Model.TableModelfbsearch;
import myfbsearch.View.fbsearchView;

/**
 *
 * @author francismschappo
 */
public class fbsearchController {

    private TableModelfbsearch modelfbsearch;
    private fbsearchView fbview;
    
    public fbsearchController(TableModelfbsearch modelfbsearch, fbsearchView fbview)
    {
        this.modelfbsearch = modelfbsearch;
        this.fbview = fbview;
    }  
    
    public void mandaver() {
        modelfbsearch.setToken(fbview.getToken().getText());
        modelfbsearch.setBusca(fbview.getUser().getText());
        
        fbsearch Search = new fbsearch();
        modelfbsearch.add(Search);
    }
    
   
    
    public int getId(){
        return modelfbsearch.getId();
    }
//    private myfbsearch.Model model;
    
    
}
