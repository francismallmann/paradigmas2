/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfbsearch.Model;

import javax.swing.ImageIcon;

/**
 *
 * @author francismschappo
 */
public class fbsearch {
    
    private String id;
    private String name;
    private ImageIcon picture;
    private ImageIcon image;
    
    public fbsearch(){
        
    }
    
    public fbsearch(String id, String name, ImageIcon picture, ImageIcon image){
        this.id = id;
        this.name = name;
        this.picture = picture;
        this.image = image;
    }
    
    public String getId(){
        return id;
    }
    
    public String getName(){
        return name;
    }
    
    public ImageIcon getPicture(){
        return picture;
    }
    
    public ImageIcon getImage(){
        return image;
    }
    
}
