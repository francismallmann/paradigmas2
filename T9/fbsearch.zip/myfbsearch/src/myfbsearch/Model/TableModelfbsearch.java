package myfbsearch.Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.restfb.Connection;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.types.User;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author francismschappo
 */
public class TableModelfbsearch extends AbstractTableModel{
    
    private static final String[] colunas = {"#", "Picture", "Id", "Name"};
    
    private String token;
    private String busca;
    private BufferedImage image;
    private int numid;
    private FacebookClient fbClient;
    private String imagem;
    
    private ArrayList<fbsearch> usuarios;
    
    public TableModelfbsearch (){
        usuarios = new ArrayList<fbsearch>();
    }
    
    @Override
    public int getRowCount() {
        return usuarios.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }  

    @Override
    public String getColumnName(int columnIndex) {
        return colunas[columnIndex];
    }
 
    public String getToken(){
        return token;
    }

    public String Search(){
        return busca;
    }
    
    
    public int getId(){
        return numid;
    }
    
    public void setToken(String token){
        this.token = token;
    }
    
    public void setBusca(String busca){
        this.busca = busca;
    }
    
    public void add(fbsearch minhabusca){
        fbClient= new DefaultFacebookClient(token, Version.VERSION_2_5);
        Connection<User> profilesFound = fbClient.fetchConnection("search", User.class, 
                Parameter.with("q", busca), Parameter.with("type", "user"),
                Parameter.with("limit", 5000), Parameter.with("offset", 0));
        
        numid = profilesFound.getData().size();

        List<User> pages = profilesFound.getData();
        
        for(User p : pages){
            User user = fbClient.fetchObject(p.getId(), User.class, Parameter.with("fields", "picture")); 
            //get the image by the url
            try {
                image = ImageIO.read(new URL(user.getPicture().getUrl()));
            } catch (IOException e) {
                Logger.getLogger(fbsearch.class.getName()).log(Level.SEVERE, null, e);
            }
            
            fbsearch client = new fbsearch(p.getName(), p.getId(), (new ImageIcon(image)), image);
            usuarios.add(client);
            fireTableRowsInserted(usuarios.size()-1, usuarios.size()-1);

        }
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex) {
            case 0: return (rowIndex+1);
            case 1: return usuarios.get(rowIndex).getImage();
            case 2: return usuarios.get(rowIndex).getId();
            case 3: return usuarios.get(rowIndex).getName();
        }
        return usuarios.get(rowIndex);
    }

    
}
