package myfbsearch.Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import Upload.Upload;
import com.restfb.Connection;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.types.User;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author francismschappo
 */
public class TableModelfbsearch extends AbstractTableModel{
    
    private static final String[] colunas = {"#", "ID", "Nome", "Foto"};
    
    private String token;
    private String busca;
    private BufferedImage image;
    private int numid;
    private FacebookClient fbClient;
    private String imagem;
    
    private ArrayList<fbsearch> usuarios;
    
    public TableModelfbsearch (){
        usuarios = new ArrayList<fbsearch>();
    }
    
    @Override
    public int getRowCount() {
        return usuarios.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }  

    public String[] getColumnsName(){
        return colunas;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return colunas[columnIndex];
    }
 
    public String getToken(){
        return token;
    }

    public String Search(){
        return busca;
    }
    
    
    public int getId(){
        return numid;
    }
    
    public void setToken(String token){
        this.token = token;
    }
    
    public void setBusca(String busca){
        this.busca = busca;
    }
    
     @Override
    public Class<?> getColumnClass(int column) {
        switch(column) {
            case 0: return String.class;
            case 1: return Object.class;
            case 2: return String.class;
            case 3: return ImageIcon.class;
            default: return Object.class;
        }
    }

    public void add(fbsearch minhabusca){
        fbClient= new DefaultFacebookClient(token, Version.LATEST);
        Connection<User> profilesFound = fbClient.fetchConnection("search", User.class, 
                Parameter.with("q", busca), Parameter.with("type", "user"),
                Parameter.with("limit", 5000), Parameter.with("offset", 0));
        
        numid = profilesFound.getData().size();

        List<User> pages = profilesFound.getData();
        
        for(User p : pages){
            User user = fbClient.fetchObject(p.getId(), User.class, Parameter.with("fields", "picture")); 
            //get the image by the url
            try {
                image = ImageIO.read(new URL(user.getPicture().getUrl()));
            } catch (IOException e) {
                Logger.getLogger(fbsearch.class.getName()).log(Level.SEVERE, null, e);
            }
            
            
            fbsearch client = new fbsearch(p.getName(), p.getId(), (new ImageIcon(image)), new ImageIcon(image));
            
            usuarios.add(client);
            fireTableRowsInserted(usuarios.size()-1, usuarios.size()-1);
        }
        Upload upload = new Upload();
        for(fbsearch objeto : usuarios){
            upload.salvaImage(objeto.getPicture());
            System.out.println(objeto.getName());
        }
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex) {
            case 0: return (rowIndex+1);
            case 1: return usuarios.get(rowIndex).getName();
            case 2: return usuarios.get(rowIndex).getId();
            case 3: {
                ImageIcon imageIcon = usuarios.get(rowIndex).getImage();
                /**Image img = imageIcon.getImage();
                BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB); 
                Graphics g = bi.createGraphics(); 
                g.drawImage(img, 0, 0, 150, 200, null); 
                ImageIcon newIcon = new ImageIcon(bi); */
                return imageIcon;
            }
        }
        return usuarios.get(rowIndex);
    }

    
}
