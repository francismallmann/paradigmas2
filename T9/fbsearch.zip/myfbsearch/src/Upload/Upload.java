/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Upload;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 *
 * @author francismschappo
 */
public class Upload {
    
    private ImageIcon image;
    private int contador = 0;

    public Upload() {
    }
    
    public Upload(ImageIcon image) {
        this.image = image;
    }

    public ImageIcon getImage() {
        return image;
    }

    public void setImage(ImageIcon image) {
        this.image = image;
    }

    
// cast it to bufferedimage

    public void salvaImage(ImageIcon image){
    
    Image imagen = image.getImage();
        
    BufferedImage buffered = (BufferedImage) imagen;

    try {
    // save to file - trocar output dependendo do SO e cuidar os privilegios de gravacao
        File outputfile = new File("/Users/francismschappo/Desktop/myfbsearch/saved"+this.contador+".jpg");
        ImageIO.write(buffered, "jpg", outputfile);
        contador++;

    } catch (IOException e) {
        e.printStackTrace();
        }
    }
}